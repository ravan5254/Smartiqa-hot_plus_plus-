#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "client.h"
#include "avis.h"
#include <QMessageBox>
#include <QComboBox>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
ui->setupUi(this);
ui->tabclient->setModel(tmpclient.afficher());
ui->tableavis->setModel(tmpavis.afficher());
ui->comboBox->setModel(tmpclient.getIdModel());
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_12_clicked()
{

    QString idClient=ui->lineEdit_idClient->text();
    QString nom= ui->lineEdit_nom->text();
    QString prenom= ui->lineEdit_prenom->text();
    QString email= ui->lineEdit_email->text();
    int numero = ui->lineEdit_num->text().toInt();
    Client c(idClient,nom,prenom,email,numero);
    bool test= c.ajouter(c);
  if(test)
{ui->tabclient->setModel(tmpclient.afficher());//refresh
QMessageBox::information(nullptr, QObject::tr("Ajouter un client"),
                  QObject::tr("client ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::information(nullptr, QObject::tr("Ajouter un client"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_pushButton_3_clicked()
{   Client cc;
    QSqlQueryModel * p=cc.tri();
    ui->tabclient ->setModel(tmpclient.tri());
    ui->tabclient->setModel(p);

}


void MainWindow::on_pushButton_2_clicked()
{
    QString nom =ui->idClient2_2->text();



     bool test=tmpclient.recherchernomclient(nom);
     if (test)
     {ui->tabclient->setModel(tmpclient.recherchernomclient(nom));
         QMessageBox::information(nullptr, QObject::tr("Rechercher un client"),
                           QObject::tr(" client existe  .\n"
                                       "Click Cancel to exit."), QMessageBox::Cancel);
    }
     else

     QMessageBox::critical(nullptr, QObject::tr("Rechercher un client"),
                 QObject::tr("Erreur !.\n"
                             "essayez une autre fois !"), QMessageBox::Retry);
}

void MainWindow::on_pushButton_clicked()
{


QString idClient = ui->comboBox->currentText();
QString nom=ui->lineEdit_nom_1->text();
QString prenom= ui->lineEdit_prenom_->text();
QString email=ui->lineEdit_email_2->text();
int numero=ui->lineEdit_num_1->text().toInt();

Client C (idClient,nom,prenom,email,numero);


bool test=C.modifier(C);

if (test)
{ ui->tabclient->setModel(tmpclient.afficher());//refresh
    ui->comboBox->setModel(tmpclient.getIdModel());
QMessageBox::information(nullptr, QObject::tr("modifier un client"),
                  QObject::tr(" client modifié .\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
}
}

void MainWindow::on_pb_supprimer_clicked()
{
    QString idClient= ui->idClient2->text();
           Client c;

                 bool test=tmpclient.supprimer(idClient);
                  // test=c.supprimer(idClient);

           if(test)
           {ui->tabclient->setModel(tmpclient.afficher());//refresh
               ui->comboBox->setModel(tmpclient.getIdModel());
               QMessageBox::information(nullptr, QObject::tr("Supprimer un client"),
                           QObject::tr("client supprimé.\n"
                                       "Click Cancel to exit."), QMessageBox::Cancel);

           }
           else if (!test)
              { QMessageBox::critical(nullptr, QObject::tr("Supprimer un client"),
                           QObject::tr("Erreur !.\n"
                                       "Click Cancel to exit."), QMessageBox::Cancel);
     }

}

//Avis

void MainWindow::on_pushButton_4_clicked()
{ QString num=ui->num->text();
    QString idClient= ui->nomclient->text();
    QString dateavis= ui->dateavis->text();
    QString etat = ui->etat ->text();
   Avis a (num,dateavis,etat,idClient);
    bool test= a.ajouter(a);
  if(test)
{ui->tableavis->setModel(tmpavis.afficher());//refresh
QMessageBox::information(nullptr, QObject::tr("Ajouter un avis"),
                  QObject::tr("avis ajoutée.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::information(nullptr, QObject::tr("Ajouter un avis"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
 //tri avis

void MainWindow::on_pushButton_16_clicked()
{
    Avis aa;
       QSqlQueryModel * a=aa.tri();
       ui->tableavis->setModel(tmpavis.tri());
       ui->tableavis->setModel(a);
}

//modifier avis

void MainWindow::on_pushButton_8_clicked()
{
    QString num=ui->numa2->text();
        QString idClient= ui->numclient2->text();
        QString dateavis= ui->dateavis2->text();
        QString etat= ui->etat_2->text();
      Avis a  (num,dateavis,etat,idClient);


    bool test=a.modifier(a);

    if (test)
    { ui->tableavis->setModel(tmpavis.afficher());//refresh
    QMessageBox::information(nullptr, QObject::tr("modifier une avis"),
                   QObject::tr(" avis modifié .\n"
                               "Click Cancel to exit."), QMessageBox::Cancel);
    }

}
//supprimer avis

void MainWindow::on_pushButton_9_clicked()
{QString numR= ui->suppR->text();
 Avis a ;

          bool test=tmpavis.supprimer(numR);


    if(test)
    {
        QMessageBox::information(nullptr, QObject::tr("Supprimer un avis"),
                    QObject::tr("avis supprimée.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else if (!test)
       { QMessageBox::critical(nullptr, QObject::tr("Supprimer un avis"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    }

}


void MainWindow::on_pushButton_11_clicked()
{
    QString numAviss=ui->lineEdit_10->text();  /*->currentText();*/



        bool test=tmpavis.rechercher(numAviss);
        if (test)
        { ui->tableView_4->setModel(tmpavis.rechercher(numAviss));
        QMessageBox::information(nullptr, QObject::tr("Rechercher un avis "),
                          QObject::tr("Avis non trouvé "), QMessageBox::Cancel);
        }
        else
            QMessageBox::critical(nullptr, QObject::tr("Recherche un avis"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);
}
