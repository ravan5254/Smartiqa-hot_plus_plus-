#include "avis.h"
#include <QDebug>
Avis::Avis()
{
num ="";
dateavis="";
etat="";
idClient="";


}
Avis::Avis(QString num,QString dateavis,QString etat ,QString idClient)
{
  this->num=num;
  this->dateavis=dateavis;
  this->etat=etat;
   this->idClient=idClient;


}



bool Avis::ajouter(Avis a)
{
    QSqlQuery query;

    query.prepare("INSERT INTO TABAVIS (NUM, DATEAVIS, ETAT,  IDCLIENT) "
                        "VALUES (:num, :dateavis, :etat, :idClient)");
    query.bindValue(":num",a.get_num());
    query.bindValue(":dateavis",a.get_dateavis());
    query.bindValue(":etat",a.get_etat());
    query.bindValue(":idClient",a.get_idClient());

    return query.exec();
}


QSqlQueryModel * Avis::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from TABAVIS");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("Num"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Dateavis "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Etat"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("idClient"));

    return model;
}

bool Avis::supprimer(QString Numm)
{
QSqlQuery query;
//QString idClient= QString::number(iddclient);
query.prepare("Delete from TABAVIS where idClient = :idClient ");
query.bindValue(":NUM", Numm);
return    query.exec();
}
bool Avis::modifier(Avis a)
{
    QSqlQuery query;

       query.prepare("UPDATE TABAVIS SET NUM =:num , DATEAVIS =:dateavis , ETAT =:etat ,IDCLIENT:=idClient WHERE NUM =:num ");
       query.bindValue(":num",a.get_num());
       query.bindValue(":dateavis",a.get_dateavis());
       query.bindValue(":etat",a.get_etat());
       query.bindValue(":idClient",a.get_idClient());

    return query.exec();
}
QSqlQueryModel *Avis::tri()
{
QSqlQuery *q = new QSqlQuery();
QSqlQueryModel *model = new QSqlQueryModel();
q->prepare("SELECT * FROM TABAVIS ORDER BY NOM");
q->exec();
model->setQuery(*q);
return model;
}


QSqlQueryModel *Avis::rechercher(QString num)
{

//QString cinn= QString::number(idclient);
QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("SELECT * FROM TABAVIS WHERE NOM like '"+num+"%' ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("Num"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Dateavis "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Etat"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("idClient"));
return model;

}
