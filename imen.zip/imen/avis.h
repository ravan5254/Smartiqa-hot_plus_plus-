#ifndef AVIS_H
#define AVIS_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>

class Avis
{  public:
    Avis() ;
    Avis(QString ,QString ,QString,QString);
    QString get_num( ){return num ;}
    QString get_dateavis(){ return  dateavis;}
    QString get_etat() {return etat ;}
    QString get_idClient(){return  idClient ;}

    void setnum(QString);
    void setdateavis(QString);
    void setetat(QString);
    void setidClient(QString);

    bool ajouter(Avis a);
    bool modifier (Avis a);
    bool supprimer(QString iddclient);
    QSqlQueryModel * afficher();
    QSqlQueryModel *rechercher(QString);
    QSqlQueryModel *tri();

    private:
    QString num,dateavis,etat, idClient;


};

#endif // AVIS_H

